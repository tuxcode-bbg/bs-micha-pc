--[[
	configuration

	Add your own configuration keywords here.
	This file overrides /share/xupnpd/xupnpd_cfg.lua
]]

--cfg.name='my_xupnpd'
