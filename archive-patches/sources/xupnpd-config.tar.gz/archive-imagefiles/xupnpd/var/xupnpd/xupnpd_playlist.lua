--[[
	playlist (m3u file path or path with alias)

	Add your own playlist here.
	This file overrides /share/xupnpd/xupnpd_playlist.lua
]]
