--[[
	feeds list (plugin, feed name, feed type)

	Add your own feeds here.
	This file overrides /share/xupnpd/xupnpd_feeds.lua
]]
