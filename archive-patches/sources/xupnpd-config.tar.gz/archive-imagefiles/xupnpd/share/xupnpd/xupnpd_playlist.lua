--[[
	playlist (m3u file path or path with alias)
]]

playlist=
{
   { '/media/sda1/movies',		'Local Record Files' },
   { '/media/sda1/pictures',		'Local Picture Files' },
   { './playlists/youtube_music.m3u',	'YouTube - Music - Playlist by NI' },
}
