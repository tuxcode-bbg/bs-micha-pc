--[[
	feeds list (plugin, feed name, feed type)
]]

feeds=
{
   { 'coolstream',     'localhost',            'CST' },
   { 'youtube',        'simonscat',            'YouTube - Simon\'s Cat' },
   { 'youtube',        'redbullracing',        'YouTube - Infiniti Red Bull Racing' },
   { 'youtube',        'Postillon24',          'YouTube - Postillon24' },
   { 'youtube',        'Netzkino',             'YouTube - Netzkino' },
   { 'youtube',        'redbullracing',        'YouTube - Infiniti Red Bull Racing' },
   { 'youtube',        'sport1psprofis',       'YouTube - Die PS-Profis' },
   { 'youtube',        'spiegeltv',            'YouTube - Spiegel TV' },
   { 'vimeo',          'channel/hd',           'Vimeo HD Channel' },
   { 'vimeo',          'channel/hdmusicvideos','Vimeo HD Music' },
   { 'vimeo',          'channel/stereoscopy',  'Vimeo Oldschool 3D Filme' },
   { 'vimeo',          'channel/31259',        'Vimeo Independent Filmmakers' },
   { 'vimeo',          'group/hdxs',           'Vimeo HD Extremsport' },
   { 'youporn',        'top_rated',            'YouPorn - Top Rated' },
}
